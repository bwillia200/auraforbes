class Passenger{
	constructor(name, desiredFloor){
	  	this.name = name;
	  	this.desiredFloor = desiredFloor;
	  	return this;
	};
};	

exports["default"] = Passenger;
module.exports = exports["default"];

